=== PS Chat ===
Contributors: DerN3rd (NerdService Eimen)
Tags: multisite, chat, community, messenger, support
Requires at least: 4.9
Tested up to: 6.8.1
Stable tag: 1.1.0
Requires PHP: 7.0
License: GPLv2 or later
License URI: https://www.gnu.org/licenses/gpl-2.0.html

Erlaube Deinen Usern, mit Dir oder anderen Usern zu chatten. Inkl. Gruppenchats. Keine Drittanbieter, keine externen Abo-Kosten!

== Description ==

Das mächtigste Livechat Tool zum selbsthosten für WordPress. Vorsicht, je nach Auslastung kann der Betrieb des Chat-Tools eine hohe Server-Last verursachen.
Manche Hosting-Anbieter oder V-Server könnten Dich für einen Spammer halten. Stelle sicher das Du entweder niedrigere Abfrageintervalle einstellst oder ein
entsprechendes Hosting, zB. einen Root-Server Dein Eigen nennst.

[POWERED BY Power-SOURCE](https://github.com/Power-Source)
Online Geld verdienen macht dieses mächtige Leichtgewicht von eCommerce Plugin im Nu Kinderleicht.

[Projektseite](https://power-source.github.io/ps-chat/)



== ChangeLog ==

= 1.1.0 =

* Emoji-Picker: Modal im Chatfenster, kompaktere Emojis, Suchfeld, Tabs
* Sendebutton: Option rechts als Icon, unten weiterhin Text, DOM-Logik korrigiert
* Fehlerbehebung: 500er im Poll behoben (Filter-Parameter angepasst)
* Cleanup: Debug-Logs im JS entfernt; Produktions-Logging wieder deaktiviert

= 1.0.0 =

* Veröffentlichung


